//
//  VK_Client_SwiftUIApp.swift
//  VK-Client-SwiftUI
//
//  Created by Илья Лебедев on 05.10.2021.
//

import SwiftUI

@main
struct VK_Client_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
